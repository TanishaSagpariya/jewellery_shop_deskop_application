﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace jewellery_shop
{
    public partial class Items : Form
    {
        public Items()
        {
            InitializeComponent();
            populate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ItName.Text == "" || PriceTb.Text == "" || QtyTb.Text == "" || CatCb.SelectedIndex == -1 || TypeCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update ItemTbl set ItName='" + ItName.Text + "',ItCat='" + CatCb.SelectedItem.ToString() + "',ItType='" + TypeCb.SelectedItem.ToString() + "',ItPrice='" + PriceTb.Text + "',ItQty='" + QtyTb.Text + "' where ItId=" + key + ";";

                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Updated Successfully");

                    Con.Close();
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

            //if (ItName.Text == "" || PriceTb.Text == "" || QtyTb.Text == "" || CatCb.SelectedIndex == -1 || TypeCb.SelectedIndex == -1)
            //{
            //    MessageBox.Show("Missing Information");
            //}
            //else
            //{
            //    try
            //    {
            //        Con.Open();
            //        string query = "update ItemTbl set ItName='" + ItName.Text + "',ItCat='" + CatCb.SelectedItem.ToString + "',ItType='" + TypeCb.SelectedItem.ToString() + "',ItPrice='" + PriceTb.Text + "',ItQty='" + QtyTb.Text + "'where ItId=" + key + ";";

            //        SqlCommand cmd = new SqlCommand(query, Con);
            //        cmd.ExecuteNonQuery();
            //        MessageBox.Show("Item Updated Successfully");

            //        Con.Close();
            //        populate();
            //        Reset();
            //    }
            //    catch (Exception Ex)
            //    {
            //        MessageBox.Show(Ex.Message);
            //    }
            //}
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Tanisha Sagpariya\OneDrive\Pictures\Documents\JewelleryDb.mdf;Integrated Security=True;Connect Timeout=30");
        private void populate()
        {
            Con.Open();
            string query = "select *from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void FilterByCat()
        {
            Con.Open();
            string query = "select *from ItemTbl where ItCat='"+FilterCat.SelectedItem.ToString()+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void FilterByType()
        {
            Con.Open();
            string query = "select *from ItemTbl where ItType='" + FilterType.SelectedItem.ToString() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if(ItName.Text==""||PriceTb.Text==""||QtyTb.Text==""||CatCb.SelectedIndex == -1 || TypeCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into ItemTbl values('" + ItName.Text + "','" + CatCb.SelectedItem.ToString() + "','" + TypeCb.SelectedItem.ToString() + "','" + PriceTb.Text + "','" + QtyTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Saved Successfully");
                    
                    Con.Close();
                    populate();
                    Reset();
                }catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
            
    }
        int key = 0;
        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow row = ItemDGV.Rows[e.RowIndex];
                ItName.Text = row.Cells[1].Value.ToString();
                CatCb.SelectedItem = row.Cells[2].Value.ToString();
                TypeCb.SelectedItem = row.Cells[3].Value.ToString();
                PriceTb.Text = row.Cells[4].Value.ToString();
                QtyTb.Text = row.Cells[5].Value.ToString();

                
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }
        private void Reset()
        {
            ItName.Text = "";
            CatCb.SelectedIndex = -1;
            TypeCb.SelectedIndex = -1;
            PriceTb.Text = "";
            QtyTb.Text = "";
            key = 0;
        }
        private void ResetBtn_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from ItemTbl where ItId=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted Successfully");

                    Con.Close();
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Customers Obj = new Customers();
            Obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FilterCat_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FilterByCat();
        }

        private void FilterType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FilterByType();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            populate();
        }
        //    ItName.Text = ItemDGV.SelectedRows[0].Cells[1].Value.ToString();
        //    CatCb.SelectedItem = ItemDGV.SelectedRows[0].Cells[2].Value.ToString();
        //    TypeCb.SelectedItem = ItemDGV.SelectedRows[0].Cells[3].Value.ToString();
        //    PriceTb.Text = ItemDGV.SelectedRows[0].Cells[4].Value.ToString();
        //    QtyTb.Text = ItemDGV.SelectedRows[0].Cells[5].Value.ToString();
        //    if(ItName.Text == "")
        //    {
        //        key = 0;
        //    }else
        //    {
        //        key = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[0].Value.ToString());
        //    }
        // }
    }
    }

